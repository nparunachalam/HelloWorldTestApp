//
// Created by Gleb Morgachev on 3/7/23.
// Copyright (c) 2023 Product Science. All rights reserved.
//

#import <Foundation/Foundation.h>
#include <dlfcn.h>
#import "fishhook.h"
#import <Network/Network.h>


void install_async_hooks(const int8_t *);
