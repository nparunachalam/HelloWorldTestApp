//
//  Copyright © 2022 Product Science. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN


/// Info collected and returned by the hooks on `NSURLSessionTask`'s `setState:`.
@interface PSKSessionTaskStateInfo: NSObject

@property (nonatomic, readonly) NSURLSessionTask *task;
@property (nonatomic, readonly) NSURLSessionTaskState state;
@property (nonatomic, readonly, nullable) NSURLSessionTaskMetrics *metrics;
@property (nonatomic, readonly) NSString *sessionID;
@property (nonatomic, readonly) NSString *taskUUID;

@end

@interface NSURLSessionTask (PSKit)

/// Hook entry/exit of `-[NSURLSessionTask setState]`.
+ (void)psk_addStateHooksBefore:(void (^)(PSKSessionTaskStateInfo *))before
                          after:(void (^)(PSKSessionTaskStateInfo *))after;

/// Un-hook all hooked `NSURLSessionTask` methods.
+ (void)psk_removeAllHooks;

@end

NS_ASSUME_NONNULL_END
