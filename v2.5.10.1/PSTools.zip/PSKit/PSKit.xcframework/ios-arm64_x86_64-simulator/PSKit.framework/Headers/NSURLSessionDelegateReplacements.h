//  
//  Copyright © 2023 Product Science. All rights reserved.
//

#import <Foundation/Foundation.h>


NS_ASSUME_NONNULL_BEGIN

@interface PSKSessionDelegateInfo: NSObject

@property (nonatomic, readonly) NSURLSessionTask *task;
@property (nonatomic, readonly) NSString *taskUUID;
@property (nonatomic, readonly) NSString *className;
@property (nonatomic, readonly) NSString *selectorName;

- (id)initWithTask:(NSURLSessionTask *)task
          taskUUID:(NSString *)taskUUID
         className:(NSString *)className
      selectorName:(NSString *)selectorName;

@end

NS_SWIFT_NAME(URLSessionDelegateReplacements)
@interface NSURLSessionDelegateReplacements : NSObject

@property (class, nonatomic, readonly) NSURLSessionDelegateReplacements *sharedReplacements NS_SWIFT_NAME(shared);

/// Hook entry/exit of relevant delegate methods on the provided `delegateClass`.
///
/// If `delegateClass` already has hooks, then this method is a no-op.
- (void)addTaskCompletionHooksIfNeededToClass:(Class)delegateClass
                                       before:(void (^)(PSKSessionDelegateInfo *))before
                                        after:(void (^)(PSKSessionDelegateInfo *))after;
- (void)removeAllHooks;

@end

NS_ASSUME_NONNULL_END
